module.exports.function = function getMyGPSAddr (myPoint, myPointAddr, LocationType) {
  const http = require('http');
  const console = require('console');
  const fail = require('fail');  
  var myAddr = [myPointAddr.locality +" "+ myPointAddr.subLocalityOne +" "+ myPointAddr.subLocalityTwo +" "+ myPointAddr.subLocalityThree];
  console.log(myAddr)
  
  if (myPointAddr.levelOne) {
    var sido = myPointAddr.levelOne.name;
    var sigungu = myPointAddr.locality;
    var dong = myPointAddr.subLocalityTwo;
  } else {
      var sido = myPointAddr.locality;
      var sigungu = myPointAddr.subLocalityOne;
      var dong = myPointAddr.subLocalityTwo;

  }




  const garbageLoData = require("./data/GarbageLocationInfo.js");

  console.log(garbageLoData)
  console.log(garbageLoData[0].LocationType)
  console.log(garbageLoData[1].LocationType)
  console.log(garbageLoData[2].LocationType)
  let garbageLoInfo = null;


  

  

  var result = [];

  let response = http.getUrl('https://api.sheety.co/46d38764-85dd-4f09-a26f-7e27378f3bfa' ,{format:"json", cacheTime: 0, returnHeaders: true});
  
  response = response.parsed

  console.log(response)

  


  var result = [];

  responseinfo = null;
  
  for(let i = 0; i < response.length ; i++){

     if(response[i].ctprvnNm.includes(sido) && response[i].signguNm.includes(sigungu)){
        if(response[i].manageZoneAreaNm.includes(dong) || response[i].manageZoneAreaNm.includes("전지역")){
          responseinfo = response[i]
          responseinfo.manageZoneAreaNm = responseinfo.manageZoneAreaNm.replace(/\+/gi, ", ");
          responseinfo.lvlhExhstAy = responseinfo.lvlhExhstAy.replace(/\+/gi, ", ");
          responseinfo.fdExhstDay = responseinfo.fdExhstDay.replace(/\+/gi, ", ");
          responseinfo.ruseExhstAy = responseinfo.ruseExhstAy.replace(/\+/gi, ", ");
          
          if(garbageLoData[0].LocationType == String(LocationType)){
            delete responseinfo.lvlhExhstAy
            delete responseinfo.fdExhstDay
            }
            
          if(garbageLoData[1].LocationType == String(LocationType)){
            delete responseinfo.fdExhstDay
            delete responseinfo.ruseExhstAy
            }

          if(garbageLoData[2].LocationType == String(LocationType)){
            delete responseinfo.lvlhExhstAy
            delete responseinfo.ruseExhstAy 
            }

          if(garbageLoData[3].LocationType == String(LocationType)){
            responseinfo = response[i]
            }
          //delete response.chrgDeptNm
//2안 내부에서, 넣을때 아에 전체를 넣어버리는 것이 아닌, 원하는 것만
        
          var lalong = {};
          lalong.latitude = myPoint.latitude;
          lalong.longitude = myPoint.longitude;

      

          var point = {};
          point["point"] = lalong;

          responseinfo.point = point;
          
          result.push(responseinfo);

          break;


        

        }
     
  
     
        





  
       else

       {
          responseinfo = response[i]
          responseinfo.manageZoneAreaNm = response.manageZoneAreaNm.replace(/\+/gi, ", ");
          responseinfo.lvlhExhstAy = response.lvlhExhstAy.replace(/\+/gi, ", ");
          responseinfo.fdExhstDay = response.fdExhstDay.replace(/\+/gi, ", ");
          responseinfo.ruseExhstAy = response.ruseExhstAy.replace(/\+/gi, ", ");

        
          var lalong = {};
          lalong.latitude = myPoint.latitude;
          lalong.longitude = myPoint.longitude;

      

          var point = {};

          point["point"] = lalong;

          responseinfo.point = point;

          

          
          result.push(responseinfo);


          }


        }
   
    }

    


  
     if (responseinfo == null){
            throw fail.checkedError("No Local", "NoLocal");
          }



  console.log(result)

  return result;
}