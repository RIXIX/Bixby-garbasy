module.exports = [
{
    LocationType : "재활용 쓰레기"
  
  },
  {
    LocationType : "일반 쓰레기"
    
  },
  {
    LocationType : "음식물 쓰레기"
    
  },

  {LocationType : "쓰레기 버리는 뉘앙스"}


  
  ]