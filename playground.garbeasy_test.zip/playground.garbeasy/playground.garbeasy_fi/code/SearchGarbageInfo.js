module.exports.function = function searchGabageInfo (garbageType) {
  const garbageData = require("./data/GarbageInfo.js");
  const console = require("console");
  const fail = require('fail'); 
  let garbageInfo = null;
  for(let i = 0; i < garbageData.length; i++){
      if(garbageData[i].garbageType == String(garbageType)){
        garbageInfo = garbageData[i];
        break;
        
      }
  }
  return garbageInfo;
}
