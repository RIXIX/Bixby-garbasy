module.exports = [
{
    garbageType : "종이류 재활용 쓰레기",
    disposalMethod : "종이류 재활용 쓰레기입니다. 이물질이 묻지 않게 하고 묶어서 배출 해주시고, 종이팩과컵은 종이팩 전용 수거함에 배출해주세요.",
    disposalInformation : "복합재질인 경우 일반 쓰레기에 배출해 주 세요. \n 예시) 영수증, 코팅벽지, 금·은박지" ,
    disposalInformation2 : "이물질이 있는 경우 재활용이 안되니 확인하세요. \n 예시) 기름묻은 종이·박스, 컵라면용기",
    disposalInformation3 : "비닐코팅지나 쇼핑백의 비닐끈 비닐덮개, 달력 스프링등은 제거하고 배출합니다.",
    url : "/images/PA.JPG"
  },
 
  {
    garbageType : "병류 재활용 쓰레기",
    disposalMethod : "병류 재활용 쓰레기입니다.분리수거 시 뚜껑을 제거한 후 내용물을 모두 비우고 물로 한번 헹궈 버려주세요.",
    disposalInformation : "담배꽁초과 같은 이물질이 들어 있으면 재활용이\n 안되니 꼭 주의해 주세요. ",
    disposalInformation2 :"깨진 유리는 일반쓰레기 입니다 주의해주세요.\n 예시) 깨진 유리, 깨진 거울 등",
    disposalInformation3 : "보증급 환불문구의 병은 환급하세요.\n 환급 거부 신고시 최대 5만원까지 보상 - 환경부",
    url : "/images/GG.JPG"
  },
  {
    garbageType : "금속캔·고철 재활용 쓰레기",
    disposalMethod : "금속캔·고철 재활용 쓰레기입니다. 내용물은 비우고, 가능한 압착해서 배출해 주세요.",
    disposalInformation : "가스용기는 구멍을 뚫어 가스를 제거해주세요. \n 예시) 각종 살충제용기, 부탄가스 등" ,
    disposalInformation2 : "복합 재질인 경우 분리 배출 해주세요.\n 예시) 햄 플라스틱 뚜껑, 망치·낫 나무손잡이 등",
    disposalInformation3 : "폐유 용기는 일반쓰레기 입니다. \n예시) 페인트몽, 오일통, 유해물질 포장통",
    url : "/images/STE.JPG"

  },
  
  {
    garbageType : "폐필름류 재활용 쓰레기",
    disposalMethod : "폐필름류 재활용 쓰레기입니다. 이물질이 묻어 있으면 헹궈서 배출해 주시고, 이물질 제거가 어려우면 일반 쓰레기로 배출해 주세요.",
    disposalInformation : "내용물을 비우고 물로 헹궈 이물질을 제거하여 \n배출합니다.",
    disposalInformation2 : "재활용 표시가 없는 경우 일반쓰레기입니다.\n뽁뽁이도 폐필름류로 버리시면 됩니다.",
    url : "/images/SN.JPG"
  },
  {
    garbageType : "플라스틱류 재활용 쓰레기",
    disposalMethod : "플라스틱류 재활용 쓰레기입니다. 내용물을 깨끗이 비우고, 부착상표 등 다른 재질로 된 부분을 제거하여 배출해 주세요. ",
    disposalInformation : "페트병 수거함이 있는 경우 따로 배출해주세요." ,
    disposalInformation2 : "라벨에 적혀있는 플라스틱 재질별로 배출합니다. \n 예시)페트병의 라벨과 뚜껑 분리배출",
    disposalInformation3 : "이물질 제거가 힘든 경우 일반쓰레기에 배출합니다.",
    url : "/images/PLA.JPG"
  },
  {
    garbageType : "음식물 쓰레기",
    disposalMethod : "음식물 쓰레기입니다. 음식물 쓰레기 봉투에 잘 버려주세요 딱딱한 껍질, 씨앗의 경우 일반쓰레기 입니다 주의해주세요. ",
    disposalInformation : "겉이 부드럽고 동물사료로 사용할 수 있으면 음식물 쓰레기입니다.",
    disposalInformation2 : "씨앗·껍질이 딱딱한 경우에는 일반 쓰레기입니다. \n 예시) 호두 껍질, 자두·복숭아 씨앗 ",
    disposalInformation3 : "동물 뼈, 갑각류 껍질, 생선 가시, 한약재 찌거기 등도 일반 쓰레기 입니다." , 
    url : "/images/F.JPG"
  },
  {
    garbageType : "일반 쓰레기",
    disposalMethod : "일반 쓰레기입니다. 재질에 따라 종량제 봉투 혹은 PP마대 봉투에 잘 버려주세요",
    disposalInformation : "일반종량제 봉투에 불에 타는 쓰레기를 배출합니다. \n 예시) 폐종이류,섬유류, 목재류등 ",
    disposalInformation2 : "PP마대에 불에 타지 않는 쓰레기를 배출합니다. \n 예시) 파손 유리, 사기그릇류, 조개류, 동물뼈 등",
    disposalInformation3 : "우산은 철편만 고철입니다,  분리가 어려운 경우 \n 일반쓰레기로 배츨합니다.",
    url : "/images/L.JPG"
  },
{
    garbageType : "전용수거함 쓰레기",
    disposalMethod : "전용수거함 쓰레기입니다. 동 주민센터 혹은 동네의 지정된 수거함에 잘 버려주세요",
    disposalInformation : "주민센터에 있는 전용수거함에 배출합니다. \n 예시) 형광등, 전구, 폐형광등, 태극기",
    disposalInformation2 : "재사용 가능한 의류만 의류 수거함에 배출합니다. \n 예시) 목도리 머플러 의류 등",
    disposalInformation3 : "타이어, 윤활유 등은 구입처와 상담합니다. \n 예시) 윤활유, 자동차 부품, 타이어, 엔진오일",
    url : "/images/J.JPG"
  
  },
  {
    garbageType : "의약품 쓰레기",
    disposalMethod : "의약품 쓰레기는 약국, 보건소에서 무료로 수거하고 있습니다. 분리수거를 하지않으면 심각한 환경오염을 초래하니 유의해주세요.",
    disposalInformation : "약은 약끼리 분류하고, 약봉투 및 포장케이스는 \n가정내 일반쓰레기로 배출합니다.",
    disposalInformation2 : "캡슐약은 분리해서 가루만 모아 배출합니다.",
    url : "/images/bbbb.JPG"
  }, 
  
  {
    garbageType : "대형 폐기물",
    disposalMethod : "대형 폐기물은 주민센터나 인터넷을 통해 신고한 후 폐기 스티커를 붙인 뒤 버려주세요.",
    disposalInformation : "전자 제품·가구중 1M이상이 되는 경우 \n대형 폐기물에 해당됩니다.",
    disposalInformation2 : "대형폐가전 무료 수거 문의는 ☎1599-0903 \n입니다.",
    url : "/images/R.JPG"
  },  
  {
    garbageType : "소형 폐기물",
    disposalMethod : "소형 폐기물은 동주민센터 전용 수거함에 배출해주시거나 인터넷을 통해 신청하여 버려주세요.",
    disposalInformation : "아파트의 경우 분리수거장에 수거함이 \n있을 수 있습니다.",
    disposalInformation2 : "소형폐가전 무료 수거 문의는 ☎1599-0903\n입니다",
    url : "/images/SS.JPG"
  },
    {
    garbageType : "스티로폼",
    disposalMethod : "스티로폼은 물로 헹구는 등 이물질을 제거하고, 별도로 마련된 수거함에 배출하도록 합니다.",
    disposalInformation : "건축 자재용 스티로폼은 산업폐기물입니다.",
    disposalInformation2 : "전자제품 구입시 완충재로 사용되었던 것은 \n구입처로 반납합니다.",
    url : "/images/ST.JPG"
  }
]