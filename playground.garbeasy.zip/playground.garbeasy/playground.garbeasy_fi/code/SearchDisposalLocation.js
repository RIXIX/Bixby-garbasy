module.exports.function = function getMyGPSAddr (myPoint, myPointAddr) {
  const http = require('http');
  const console = require('console');
  const fail = require('fail');  
  var myAddr = [myPointAddr.locality +" "+ myPointAddr.subLocalityOne +" "+ myPointAddr.subLocalityTwo +" "+ myPointAddr.subLocalityThree];
  console.log(myAddr)
  if (myPointAddr.levelOne) {
    var sido = myPointAddr.levelOne.name;
    var sigungu = myPointAddr.locality;
    var dong = myPointAddr.subLocalityTwo;
  } else {
      var sido = myPointAddr.locality;
      var sigungu = myPointAddr.subLocalityOne;
      var dong = myPointAddr.subLocalityTwo;

  }

  
  let response = http.getUrl('https://api.sheety.co/46d38764-85dd-4f09-a26f-7e27378f3bfa' ,{format:"json", cacheTime: 0, returnHeaders: true});
  
  response = response.parsed
  console.log(response)

  
  var result = [];
  responseinfo = null;
  for(let i = 0; i < response.length ; i++){
     if(response[i].ctprvnNm.includes(sido) && response[i].signguNm.includes(sigungu)){
        if(response[i].manageZoneAreaNm.includes(dong) || response[i].manageZoneAreaNm.includes("전지역")){
          responseinfo = response[i]
          responseinfo.manageZoneAreaNm = responseinfo.manageZoneAreaNm.replace(/\+/gi, ", ");
          responseinfo.lvlhExhstAy = responseinfo.lvlhExhstAy.replace(/\+/gi, ", ");
          responseinfo.fdExhstDay = responseinfo.fdExhstDay.replace(/\+/gi, ", ");
          responseinfo.ruseExhstAy = responseinfo.ruseExhstAy.replace(/\+/gi, ", ");

        
          var lalong = {};
          lalong.latitude = myPoint.latitude;
          lalong.longitude = myPoint.longitude;

      

          var point = {};
          point["point"] = lalong;

          responseinfo.point = point;
          console.log(responseinfo)
          result.push(responseinfo);
          break;
          
          
         
         
        }
       else
       {
          responseinfo = response[i]
          responseinfo.manageZoneAreaNm = responseinfo.manageZoneAreaNm.replace(/\+/gi, ", ");
          responseinfo.lvlhExhstAy = responseinfo.lvlhExhstAy.replace(/\+/gi, ", ");
          responseinfo.fdExhstDay = responseinfo.fdExhstDay.replace(/\+/gi, ", ");
          responseinfo.ruseExhstAy = responseinfo.ruseExhstAy.replace(/\+/gi, ", ");

        
          var lalong = {};
          lalong.latitude = myPoint.latitude;
          lalong.longitude = myPoint.longitude;

      

          var point = {};
          point["point"] = lalong;

          responseinfo.point = point;
          console.log(responseinfo)
          result.push(responseinfo);
          
        }
 
        }

       }
  
  

  
     if (responseinfo == null){
            throw fail.checkedError("No Local", "NoLocal");
          }


  
   

  return result;
}


  

